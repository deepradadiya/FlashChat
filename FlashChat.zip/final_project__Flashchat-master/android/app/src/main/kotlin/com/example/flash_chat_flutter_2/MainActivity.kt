package com.example.flash_chat_flutter_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
